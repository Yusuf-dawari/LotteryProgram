
package lotteryprogram;
import java.util.Scanner;
public class LotteryProgram {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1 = (int)(Math.random()* 10);
        int num2 = (int)(Math.random() *10);
        
        System.out.println("Enter the first golden number :");
        int goldenNum1 =input.nextInt();
         
        System.out.println("Enter the second golden number :");
        int goldenNum2 = input.nextInt();
        
        if (num1==goldenNum1 && num2 == goldenNum2){
            System.out.println("You won 10,000$");
        }
        else if (num1==goldenNum1 || num2 == goldenNum2){
            System.out.println("You won 1000$");}
        
        else if (num1==goldenNum2 && num2 == goldenNum1){
            System.out.println("You won 3000$");}
        else{System.out.println("you won nothing try again");}
        System.out.println("The golden number was"+num1+""+num2);
        
        
    
    
}}

